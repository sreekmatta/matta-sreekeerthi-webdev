(function () {
    angular
        .module("HungryOwlAppMaker")
        .controller("UserDashboardController", UserDashboardController);

    function UserDashboardController($location) {
        var viewModel = this;

        //event handlers
        viewModel.getDashboardURL = getDashboardURL;

        function getDashboardURL(userType){
            if(userType == "foodie")
                return 'views/users/templates/foodie/foodie-dashboard.view.client.html';
            else
                return 'views/users/templates/restaurant/restaurant-dashboard.view.client.html';
        }

    }
})();