(function () {
    angular
        .module("HungryOwlAppMaker")
        .config(Config);

    function Config($routeProvider,$locationProvider) {

        $routeProvider
            .when("/",{
                templateUrl: 'views/users/templates/home.view.client.html'
            })
            .when("/login",{
                templateUrl: 'views/users/templates/login.view.client.html'
            })
            .when("/register",{
                templateUrl: 'views/users/templates/register.view.client.html'
            })
            .when("/searchresults",{
                templateUrl: 'views/users/templates/search-results.view.client.html'
            })
            .when("/user/dashboard",{
                templateUrl: 'views/users/templates/user-dashboard.view.client.html',
                controller: 'UserDashboardController',
                controllerAs: 'model'
            })
            .when("/admin/dashboard",{
                templateUrl: 'views/users/templates/admin/admin-dashboard.view.client.html'
            })
    }
})();