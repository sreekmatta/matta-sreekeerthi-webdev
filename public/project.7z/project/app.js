(function () {
    angular
        .module("HungryOwlAppMaker", ["ngRoute"]);
})();